### R code from vignette source 'geograph-basics.Rnw'
### Encoding: ISO8859-1

###################################################
### code chunk number 1: load
###################################################
library(geoGraph)
search()


###################################################
### code chunk number 2: geograph-basics.Rnw:140-141
###################################################
getClass("gGraph")


###################################################
### code chunk number 3: geograph-basics.Rnw:144-145
###################################################
new("gGraph")


###################################################
### code chunk number 4: geograph-basics.Rnw:163-166
###################################################
data(worldgraph.10k)
worldgraph.10k
worldgraph.10k@meta


###################################################
### code chunk number 5: geograph-basics.Rnw:205-206
###################################################
getClass("gData")


###################################################
### code chunk number 6: geograph-basics.Rnw:209-210
###################################################
new("gData")


###################################################
### code chunk number 7: geograph-basics.Rnw:241-242 (eval = FALSE)
###################################################
## ?geoGraph


###################################################
### code chunk number 8: geograph-basics.Rnw:246-247 (eval = FALSE)
###################################################
## help("geoGraph", package="geoGraph", html=TRUE)


###################################################
### code chunk number 9: geograph-basics.Rnw:250-251 (eval = FALSE)
###################################################
## options(htmlhelp = FALSE)


###################################################
### code chunk number 10: cities
###################################################
Bordeaux <- c(-1,45)
London <- c(0,51)
Malaga <- c(-4,37)
Zagreb <- c(16,46)
cities.dat <- rbind.data.frame(Bordeaux, London, Malaga, Zagreb)
colnames(cities.dat) <- c("lon","lat")
cities.dat$pop <- c(1e6, 13e6, 5e5, 1.2e6)
row.names(cities.dat) <- c("Bordeaux","London","Malaga","Zagreb")
cities.dat


###################################################
### code chunk number 11: wg10plot
###################################################
data(worldgraph.10k)
worldgraph.10k
plot(worldgraph.10k)


###################################################
### code chunk number 12: cities
###################################################
cities <- new("gData", coords=cities.dat[,1:2], data=cities.dat[,3,drop=FALSE], gGraph.name="worldgraph.10k")
cities
plot(cities, type="both", reset=TRUE)
plotEdges(worldgraph.10k)


###################################################
### code chunk number 13: closeNode
###################################################
cities <- closestNode(cities, attr.name="habitat", attr.value="land")
plot(cities, type="both", reset=TRUE)
plotEdges(worldgraph.10k)


###################################################
### code chunk number 14: geograph-basics.Rnw:324-327
###################################################
getCoords(cities)
getNodes(cities)
getData(cities)


###################################################
### code chunk number 15: geograph-basics.Rnw:330-331
###################################################
getCoords(cities, original=FALSE)


###################################################
### code chunk number 16: geograph-basics.Rnw:335-336
###################################################
getNodesAttr(cities)


###################################################
### code chunk number 17: wg10kdefplot
###################################################
data(worldgraph.10k)
worldgraph.10k@meta$colors
head(getNodesAttr(worldgraph.10k))
table(getNodesAttr(worldgraph.10k))
plot(worldgraph.10k, reset=TRUE)
title("Default plotting of worldgraph.10k")


###################################################
### code chunk number 18: geograph-basics.Rnw:388-389 (eval = FALSE)
###################################################
## X11.options(type="Xlib")


###################################################
### code chunk number 19: geograph-basics.Rnw:392-393 (eval = FALSE)
###################################################
## X11.options(type="cairo")


###################################################
### code chunk number 20: geograph-basics.Rnw:416-417 (eval = FALSE)
###################################################
## geo.zoomin()


###################################################
### code chunk number 21: geograph-basics.Rnw:422-423 (eval = FALSE)
###################################################
## geo.zoomout()


###################################################
### code chunk number 22: geograph-basics.Rnw:428-429 (eval = FALSE)
###################################################
## geo.slide()


###################################################
### code chunk number 23: geograph-basics.Rnw:442-445
###################################################
.geoGraphEnv
ls(env=.geoGraphEnv)
get("last.plot", .geoGraphEnv)


###################################################
### code chunk number 24: citiesPlot
###################################################
plot(cities, reset=TRUE)
text(getCoords(cities), rownames(getData(cities)))


###################################################
### code chunk number 25: geograph-basics.Rnw:473-483
###################################################
transp <- function(col, alpha=.5){
    res <- apply(col2rgb(col),2, function(c) rgb(c[1]/255, c[2]/255, c[3]/255, alpha))
    return(res)
}


plot(cities, reset=TRUE)
par(xpd=TRUE)
text(getCoords(cities)+-.5, rownames(getData(cities)))
symbols(getCoords(cities)[,1], getCoords(cities)[,2], circ=sqrt(unlist(getData(cities))), inch=.2, bg=transp("red"), add=TRUE)


###################################################
### code chunk number 26: geograph-basics.Rnw:515-518
###################################################
data(rawgraph.10k)
geo.zoomin(c(35,54,-26,-10))
plotEdges(rawgraph.10k)


###################################################
### code chunk number 27: geograph-basics.Rnw:523-524
###################################################
geo.bookmark("madagascar")


###################################################
### code chunk number 28: geograph-basics.Rnw:532-537
###################################################
rawgraph.10k@meta$costs
newGraph <- rawgraph.10k
newGraph@meta$costs[2:6,2] <- 100
newGraph@meta$costs[1,2] <- 1
newGraph@meta$costs


###################################################
### code chunk number 29: geograph-basics.Rnw:542-544
###################################################
newGraph <- setCosts(newGraph, attr.name="habitat")
plot(newGraph,edge=TRUE)


###################################################
### code chunk number 30: geograph-basics.Rnw:553-555
###################################################
newGraph <- dropDeadEdges(newGraph, thres=1.1)
plot(newGraph,edge=TRUE)


###################################################
### code chunk number 31: geograph-basics.Rnw:561-563
###################################################
geo.zoomin(c(110,130,-27,-12))
geo.bookmark("australia")


###################################################
### code chunk number 32: geograph-basics.Rnw:583-585 (eval = FALSE)
###################################################
## geo.goto("autralia")
## newGraph <- geo.remove.edges(newGraph)


###################################################
### code chunk number 33: geograph-basics.Rnw:587-588
###################################################
load("Robjects/newGraph.RData")


###################################################
### code chunk number 34: geograph-basics.Rnw:605-609 (eval = FALSE)
###################################################
## plot(newGraph, edge=TRUE)
## temp <- geo.change.attr(newGraph, mode="area", attr.name="habitat", attr.value="shallowwater", newCol="deepskyblue")
## temp <- geo.change.attr(temp, attr.name="habitat", attr.value="shallowwater", newCol="deepskyblue")
## newGraph <- temp


###################################################
### code chunk number 35: geograph-basics.Rnw:611-612
###################################################
load("Robjects/newGraph2.RData")


###################################################
### code chunk number 36: geograph-basics.Rnw:614-616
###################################################
newGraph@meta$colors
plot(newGraph,edge=TRUE)


###################################################
### code chunk number 37: geograph-basics.Rnw:637-640
###################################################
world.countries <- readShapePoly(system.file("files/shapefiles/world-countries.shp",package="geoGraph"))
class(world.countries)
summary(world.countries)


###################################################
### code chunk number 38: geograph-basics.Rnw:646-650
###################################################
data(worldgraph.10k)
summary(getNodesAttr(worldgraph.10k))
newGraph <- extractFromLayer(worldgraph.10k,  layer=world.countries, attr=c("CONTINENT","NAME"))
summary(getNodesAttr(newGraph))


###################################################
### code chunk number 39: geograph-basics.Rnw:655-661
###################################################
temp <- unique(getNodesAttr(newGraph)$"NAME")
col <- c("transparent", rainbow(length(temp)-1))
colMat <- data.frame(NAME=temp, color=col)
head(colMat)
tail(colMat)
plot(newGraph, col.rules=colMat, reset=TRUE)


###################################################
### code chunk number 40: geograph-basics.Rnw:673-678
###################################################
cities.dat
cities <- new("gData", coords=cities.dat[,1:2], data=cities.dat[,3,drop=FALSE], gGraph.name="newGraph")
cities <- closestNode(cities, attr.name="habitat", attr.value="land")
getData(cities)
getNodesAttr(cities)


###################################################
### code chunk number 41: geograph-basics.Rnw:699-703
###################################################
data(hgdp)
data(worldgraph.40k)
hgdp
plot(hgdp, reset=TRUE)


###################################################
### code chunk number 42: geograph-basics.Rnw:716-717
###################################################
isConnected(hgdp)


###################################################
### code chunk number 43: geograph-basics.Rnw:724-726
###################################################
data(worldgraph.10k)
connectivityPlot(worldgraph.10k, edges=TRUE, seed=1)


###################################################
### code chunk number 44: geograph-basics.Rnw:728-730
###################################################
geo.zoomin(c(90,150,18,-25))
title("Different connected components\n in worldgraph.10k")


###################################################
### code chunk number 45: geograph-basics.Rnw:744-749
###################################################
myGraph <- dropCosts(worldgraph.40k)
hgdp@gGraph.name <- "myGraph"
addis <- cbind(38,9)
ori <- closestNode(myGraph, addis)
paths <- dijkstraFrom(hgdp, ori)


###################################################
### code chunk number 46: geograph-basics.Rnw:753-759
###################################################
addis <- as.vector(addis)
plot(newGraph, col=NA, reset=TRUE)
plot(paths)
points(addis[1], addis[2], pch="x", cex=2)
text(addis[1]+35, addis[2], "Addis abeba", cex=.8, font=2)
points(hgdp, col.node="black")


###################################################
### code chunk number 47: geograph-basics.Rnw:765-772
###################################################
div <- getData(hgdp)$"Genetic.Div"
dgeo.unif <- gPath2dist(paths, res.type="vector")
plot(div~dgeo.unif, xlab="Geographic distance (arbitrary units)", ylab="Genetic diversity")
lm.unif <- lm(div~dgeo.unif)
abline(lm.unif, col="red")
summary(lm.unif)
title("Genetic diversity vs geographic distance \n uniform costs ")


###################################################
### code chunk number 48: geograph-basics.Rnw:780-784
###################################################
myGraph@meta$costs[7,] <- c("coast", 0.25)
myGraph@meta$costs
myGraph <- setCosts(myGraph, attr.name="habitat")
paths.2 <- dijkstraFrom(hgdp, ori)


###################################################
### code chunk number 49: geograph-basics.Rnw:786-791
###################################################
plot(newGraph, col=NA, reset=TRUE)
plot(paths.2)
points(addis[1], addis[2], pch="x", cex=2)
text(addis[1]+35, addis[2], "Addis abeba", cex=.8, font=2)
points(hgdp, col.node="black")


###################################################
### code chunk number 50: geograph-basics.Rnw:796-802
###################################################
dgeo.hab <- gPath2dist(paths.2, res.type="vector")
plot(div~dgeo.hab, xlab="Geographic distance (arbitrary units)", ylab="Genetic diversity")
lm.hab <- lm(div~dgeo.hab)
abline(lm.hab, col="red")
summary(lm.hab)
title("Genetic diversity vs geographic distance \n habitat costs ")


